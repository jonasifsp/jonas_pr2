
<?php $__env->startSection('content'); ?>
<div class="row justify-content-around">
        <div class="col-md-10 ">
            <div class="card">
                <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Atque quia cumque voluptatum inventore sint eveniet qui numquam natus quo in maiores, animi cupiditate iure tempore expedita minima unde iste accusantium!</p> <div class=""> <button type="submit" id="apagar" class="btn btn-danger col-2">Apagar</button></div>
              
            </div>
            </div>
            <br><br>
<div class="form-group">

<textarea name="form-control" id="anotacao" cols="80" rows="10"></textarea>
<br><br>

<button type="submit" id="btnAnotacao" class="btn btn-success">Salvar Anotação</button>

</div></div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\gestao\gestao-verde\resources\views/anotacoes/index.blade.php ENDPATH**/ ?>