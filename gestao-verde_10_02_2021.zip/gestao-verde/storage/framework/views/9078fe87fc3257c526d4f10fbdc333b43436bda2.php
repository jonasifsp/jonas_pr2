
    
     
<?php $__env->startSection("content"); ?>


<div class="container">
    <div class="row">
        <p class="divMensage alert alert-warning"></p>
    </div>
<form id="form" action="/cliente" method="POST">
    <?php echo csrf_field(); ?>
    <?php if(isset($cliente)): ?>
    <?php echo method_field('PUT'); ?>
    <?php endif; ?>
   
<br><br>
    <div class="row">
        <div class="col-12">
            <div class="form-group">
                <p><strong>Informações</strong></p>
                <br>
            <label> Nome </label>
            <input type="text" id ="nome" name ='nome' class="form-control">
            </div>
        </div>
        

        <div class="col-12 col-sm-4">
            <div class="form-group">
            <label>Email</label>
            <input type="email" id = "email" name="email" class="form-control">
            </div>
        </div>

        
            <div class="col-12 col-sm-3">
            <div class="form-group">
            <label> CPF </label>
            <input type="text" id ="cpf" name="cpf" class="form-control">
            </div>
            </div>
            
            </div>
            <br><br>



            <p><strong>Endereço</strong> </p>
        <div class="row mt-2">
        <div class="col-12 col-sm-2">
            <div class="form-group">
            <label> CEP </label>
            <input type="text" name ="cep" id="cep" class="form-control">
            </div>
        </div>


        <div class="col-12 col-sm-5">
            <div class="form-group">
            <label> Cidade </label>
            <input type="text" id="cidade" name ="cidade" class="form-control">
            </div>
        </div>

        

        <div class="col-12 col-sm-4">
            <div class="form-group">
            <label> Bairro </label>
            <input type="text" id="bairro" name ="bairro" class="form-control">
            </div>
        </div>
       
       

        <div class="col-12 col-sm-7">
            <div class="form-group">
            <label> Logradouro </label>
            <input type="text" id="rua" name ="rua" class="form-control">
            </div>
        </div>

        <div class="col-12 col-sm-1">
            <div class="form-group">
            <label> Numero </label>
            <input type="text" id="numero" name ="numero" class="form-control">
            </div>
        </div>

      </div>

    <div class="row mt-4">
    <div class="col-12">
    <p><strong>Celular</strong></p>
 

    
    </div>


    </div>


    <div class="row mt-2 mb-3">
    <div class="col-12">
    <div class="row align-items-center">
    <div class="col-12 col-sm-4">
    <div class="form-group">
    <label for="">Celular</label>
    <input type="text" name ="telefone" id="telefone" class="form-control">
    
    </div> </div>
   </div> </div> </div>

    <button type="submit" class="btn btn-success mt-20 " id ="btnCadastrar">Cadastrar</button>
   
        



<br><br>
<script src="<?php echo e(asset('js/jquery.mask.js')); ?>"></script>
<script>
    $(document).ready(function(){
        $("#cep").mask("00000-000")
        $("#cpf").mask("000.000.000-00")
        $("#telefone").mask("(00) 00000-0000")

        $("#cep").blur(function(){
            
            var cep = $(this).unmask().val()
           
           $.ajax({
               url:"https://viacep.com.br/ws/"+cep+"/json",
               type:"GET",
             
           }).done(function(data){
            console.log("Ok:", data)
            $("#rua").val(data.logradouro),
            $("#cidade").val(data.localidade)
            $("#bairro").val(data.bairro)
           }).fail(function(){
               console.log("erro")
           }).always(function(){

           })
        })

      $('.divMensage').hide()
        
        $("#btnCadastrar").click(function(e){
            $('.divMensage').html = "";
            var elemento = document.getElementsByClassName('divMensage')
    


        
            var validaEmail =  /^(([^<>()[\]\.,;:\s@\"]+(\.[^<>()[\]\.,;:\s@\"]+)*)|(\".+\"))@(([^<>()[\]\.,;:\s@\"]+\.)+[^<>()[\]\.,;:\s@\"]{2,})$/i;
            var email = $("#email").val();

            var validaCpf = /^\d{3}\.\d{3}\.\d{3}\-\d{2}$/;
            var cpf = $("#cpf").val();
            e.preventDefault()
            if(!validaEmail.test(email)){
                $('.divMensage').append(' Email Invalido')
                $('.divMensage').fadeIn('slow')

            }else if(!validaCpf.test(cpf)){
                $('.divMensage').append(' CPF Invalido')
                $('.divMensage').fadeIn('slow')
            }else{
                $('#form').submit()
            }
        })

    })
</script>
        
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\gestao-verde\gestao-verde\resources\views/create.blade.php ENDPATH**/ ?>