
<?php $__env->startSection('content'); ?>
    <div class="row justify-content-around">
        <div class="col-md-4 ">
            <div class="card">
                <div class="card-body row-justify-content-center">
                    <button class="col btn btn-danger btn-lg" data-toggle="modal"
                        data-target="#exampleModalCenter">Relatorio de vendas pagas</button>
                </div>
            </div>
        </div>

        <div class="col-md-4  success">
            <div class="card">
                <div class="card-body row-justify-content-center">
                    <button class="col btn btn-success btn-lg   "  data-toggle="modal"   data-target="#modal2">Relatorio de vendas em atraso</button>
                </div>
            </div>
        </div>
    </div>

    <!--Modais 1-->
    <div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle"
        aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLongTitle">Relatorio vendas Pagas</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="row justify-content-center">
                        <div class="col-12">
                            <table class="table table-striped table-responsive">
                                <thead class="bg-success">
                                    <tr class="text-white">
                                        <th>Nome Cliente</th>
                                        <th>Valor</th>
                                        <th>Data compra</th>
                                        <th>Vencimento</th>
                                        <th>Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                  
                                    <?php $__currentLoopData = $dividasPagas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paga): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                   
                                    <tr>
                                      
                                        <th><?php echo e($paga->cliente->nome); ?></th>
                                        <th><?php echo e($paga->valor); ?></th>
                                        <th><?php echo e($paga->created_at); ?></th>
                                        <th><?php echo e($paga->data); ?></th>
                                        <th><?php echo e($paga->status); ?></th>
                                    
                                    </tr>
                                 
                                  
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td colspan="100">
                                            <?php if(count($dividasPagas)==0): ?>
                                            <p class="text-muted text-center"> Não há nenhum registro</p>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                    <button type="submit" id="btnCadastrar" class="btn btn-success">Salvar dívida</button>
                </div>
            </div>
        </div>
    </div>

     <!--Modais 2-->
     <div class="modal fade" id="modal2" tabindex="-1" role="dialog" aria-labelledby="modal2Title"
        aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-md" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLongTitle"> Relatorio de Vendas Em atraso</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="row justify-content-center">
                        <div class="col-12">
                            <table class="table table-striped table-responsive">
                                <thead class="bg-success">
                                    <tr class="text-white">
                                        <th>Nome Cliente</th>
                                        <th>Valor</th>
                                        <th>Data compra</th>
                                        <th>Vencimento</th>
                                        <th>Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                   <?php $__currentLoopData = $emAtraso; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $atrasada): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                      
                                        <th><?php echo e($atrasada->cliente->nome); ?></th>
                                        <th><?php echo e($atrasada->valor); ?></th>
                                        <th><?php echo e($atrasada->created_at); ?></th>
                                        <th><?php echo e($atrasada->data); ?></th>
                                        <th><?php echo e($atrasada->status); ?></th>
                                    
                                    </tr>
                                  
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td colspan="100">
                                            <?php if(count($emAtraso)==0): ?>
                                            <p class="text-muted text-center"> Não há nenhum registro</p>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                    <button type="submit" id="btnCadastrar" class="btn btn-success">Salvar dívida</button>
                </div>
            </div>
        </div>
    </div>





</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\gestao-verde\gestao-verde\resources\views/relatorios/index.blade.php ENDPATH**/ ?>