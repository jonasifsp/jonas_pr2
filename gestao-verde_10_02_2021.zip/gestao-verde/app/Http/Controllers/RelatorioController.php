<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Divida;

class RelatorioController extends Controller
{
    public function show()
    {
        $dataAtual =  Date('Y-m-d h:m:s');
        $dividasPagas = Divida::where('status','Pago')->get();
       
        $emAtraso = Divida::where('data','<', $dataAtual)->where('status' ,'<>','Pago')->get();
        foreach($emAtraso  as $divida){
            if($dataAtual> $divida->data){
                $divida->status = "Em Atraso";
                $divida->save();
            }
        }
        return view('relatorios.index', compact('emAtraso','dividasPagas'));
    }
}
