<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Anotacao extends Model
{
    public $timestamps = true;
    protected $table="anotacao";
    protected $filleble = ["title", "descricao","user_id"];


    public function usuario(){
        return $this->belongsTo("App\User");
    }
}
