<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Endereco extends Model
{
    //
    protected $table= 'endereco';
    protected $fillable =['rua','cep','numero','bairro','cidade','id_cliente'];


    public function cliente(){
        return $this->belongsTo('App\Models\Cliente');
    }
}
