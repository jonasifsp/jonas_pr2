<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Divida extends Model
{
    protected $table = "dividas";
    protected $fillable = ["valor", "data", "cliente_id", "status" ];


    public function cliente(){
        return $this->belongsTo("App\Models\Cliente");

    }
}
