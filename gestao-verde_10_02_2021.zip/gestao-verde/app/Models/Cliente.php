<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Cliente extends Model
{
    protected $table = "clientes";
    protected $fillable = ["nome", "email", "cpf", "telefone"];

    public function endereco(){
        return $this->hasOne("App\Models\Endereco");

    }
    public function dividas(){
        return $this->hasMany("App\Models\Divida");
    }
}
