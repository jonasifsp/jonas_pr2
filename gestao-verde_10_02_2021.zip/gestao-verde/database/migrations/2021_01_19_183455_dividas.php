<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class Dividas extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create("dividas", function(Blueprint $table){
            $table->id();
            $table->double("valor");
            $table->date("data");
            $table->timestamps();
            $table->foreignId("cliente_id")->constrained("clientes")->onDelete("cascade");
            $table->string ("status")->nullable();

        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('dividas');
    }
}
