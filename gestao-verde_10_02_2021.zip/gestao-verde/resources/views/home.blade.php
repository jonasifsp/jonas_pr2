@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header bg-success text-white">{{ __('Tela inicial') }}</div>

                <div class="card-body">
                    @if (session('status'))
                        <div class="alert alert-success" role="alert">
                            {{ session('status') }}
                        </div>
                    @endif

                    {{ __('Você entrou no sistema!') }}
                    <br><br>
                    <a href="{{ url('/anotacoes/index') }}"class="text-blue">Anotações</a> <br>
                    <a href="{{ url('/cliente/create') }}" class="text-success">Cadastrar Cliente</a> <br>
                    <a href="{{ url('/relatorios/index') }}"class="text-warning">Relatórios </a> <br>
                    <a href="{{ url('/dividas') }}"class="text-danger">Dividas</a> <br>
                    
                    
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
