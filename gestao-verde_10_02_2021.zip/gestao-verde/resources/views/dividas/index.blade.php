@extends('layouts.app')
@section('content')
    <div class="row justify-content-around">
        <div class="col-md-4 ">
            <div class="card">
                <div class="card-body row-justify-content-center">
                    <button class="col btn btn-danger btn-lg" data-toggle="modal"
                        data-target="#exampleModalCenter">Adicionar Dívida</button>
                </div>
            </div>
        </div>

        <div class="col-md-4  success">
            <div class="card">
                <div class="card-body row-justify-content-center">
                    <button class="col btn btn-success btn-lg   "  data-toggle="modal"   data-target="#modal2">Quitar Dívida</button>
                </div>
            </div>
        </div>
    </div>

    <!--Modais 1-->
    <div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle"
        aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLongTitle">Adicionar Dívida</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="row justify-content-center">
                        <div class="col-12">
                            <p class="alert alert-warning msg"></p>
                            <form action="/dividas" method="POST" id="form">
                                @csrf
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Nome do Cliente</label>
                                    <select name="cliente_id" class="form-control" id="nome">
                                        <option value="0">Selecione um Cliente </option>
                                        @foreach($clientes as $cliente)
                                        <option value="{{$cliente->id}}">{{$cliente->nome}}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="Valor">Valor</label>
                                    <input type="text" name="valor" class="form-control" id="valor" numeric placeholder="Informe o valor">
                                </div>
                                <div class="form-group">
                                    <label for="Valor">Data de Vencimento</label>
                                    <input type="date" name="data" class="form-control" id="data">
                                </div>

                                
                            </form>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                    <button type="submit" id="btnCadastrar" class="btn btn-success">Salvar dívida</button>
                </div>
            </div>
        </div>
    </div>

     <!--Modais 2-->
     <div class="modal fade" id="modal2" tabindex="-1" role="dialog" aria-labelledby="modal2Title"
        aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-md" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLongTitle">Quitar Dívida</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="row justify-content-center">
                        <div class="col-12">
                            <table class="table table-striped table-responsive">
                                <thead class="bg-success">
                                    <tr class="text-white">
                                        <th>Nome Cliente</th>
                                        <th>Valor</th>
                                        <th>Data compra</th>
                                        <th>Vencimento</th>
                                        <th>Ação</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach($dividas as $divida)
                                    <tr>
                                      
                                        <th>{{$divida->cliente->nome}}</th>
                                        <th>$ {{$divida->valor}}</th>
                                        <th>{{$divida->created_at}}</th>
                                        <th>{{$divida->data}}</th>
                                        <th><button class="btn btn-success btnQuitar" data-id="{{$divida->id}}">Quitar</button></th>
                                    
                                    </tr>
                                  
                                    @endforeach
                                    @if(count($dividas)==0)
                                    <tr>
                                        <td colspan=100> <p class="text-muted text-center">Nenhuma divida em aberto</p></td>
                                    </tr>
                                    @endif
                                </tbody>
                            </table>
                        
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                    <button type="submit" id="btnCadastrar" class="btn btn-success">Salvar dívida</button>
                </div>
            </div>
        </div>
    </div>




<script src="{{asset('js/jquery.mask.js')}}"></script>
<script>
    $(document).ready(function(){
        $(".msg").hide()
        $("#btnCadastrar").click(function(e){
            e.preventDefault()
            var validvalor =/^\d{0,2}(?:\.\d{0,2}){0,1}$/
            var cliente = $("#cliente").val()
            var valor =  $("#valor").val()
            var mensagens= "";
            var erros = false;
            
            if (cliente== 0  ){
               mensagem +="Selecione um cliente<br>";
               erro =true 
            }
            if (!validvalor.test(valor)  ){
               mensagem ="Informe um valor valido <br>";
               erro =true 
            }
            if(!erros){
                $("#form").submit()
            }
            else{
                $(".msg").html(mensagens)
            }

        })
        $('.btnQuitar').click(function(){
          
            console.log($(this).attr('data-id'));
           
            var id = $(this).attr('data-id');
          var linha = $(this)
            $.ajax({
                url: '/quitardivida',
                data:{
                    id :id,
                    '_token': $('input[name=_token]').val(),


                },
                type:'POST'
            }).done(function(data){
                console.log("OK", data)
                linha.parent().parent().fadeOut('slow')

            }).fail(function(){
                console.log('fail')

            })
        })
   
    })
</script>

@endsection